_________________________Version 4.0______________________________________________________________________________________
Compatible with RSA6106A/RSA6114A firmware version 1.3.71.

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Changes for Version 4.0

Added tkrsa6100 Config Phase Noise Settings.vi

Added tkrsa6100 Config Phase Noise Display.vi

Added tkrsa6100 Config Phase Noise Trace.vi

Added tkrsa6100 Phase Noise Msmt Results.vi

Added tkrsa6100 Config Spurious Settings.vi

Added tkrsa6100 Config Spurious Settings2.vi

Added tkrsa6100 Config Spurious Display.vi

Added tkrsa6100 Config Spurious Trace.vi

Added tkrsa6100 Spurious Marker Control.vi

Added tkrsa6100 Spurious Msmt Results.vi

Added tkrsa6100 Config OBW Settings 2.vi.  This add video bandwidth functions.

Added tkrsa6100 CCDF Msmt Results 2.vi.  This adds queries for trace x, y, and xy values.

Added tkrsa6100 Config RF In Trigger 2.vi.  This adds the ability to automatically generated an FMT.

Added Spurious and Phase Noise measurements to tkrsa6100 Config RF Msmts 2.vi.  Note that this will require 
updating of existing code because of changes to enumerated control Measurement.

Modified tkrsa6100 Read IQ Data.vi to correctly handle binary block transfers.  It was handling them as ascii
transfers and truncating part of the block.  Added array indicator IQ Data Array and added conversion function
tkrsa6100 Binary to Sgl Float Array Converter.vi.  This significantly speeds up binary conversions.  IQ Data
Array always gets converted data regardless of the setting of control Convert Response String (NO).

Modified tkrsa6100 Config Spectrum Settings 2.vi to add video bandwidth, new FFT window types, filter shape.
This will require existing code to be modified due to change in enumerated control Spectrum Settings.

Modified tkrsa6100 Pulse Trace Msmt Results.vi to add queries for trace x, y, and xy values.
This will require existing code to be modified due to change in enumerated control Spectrum Settings.

Modified tkrsa6100 Config Spectrogram Settings 2.vi to add video bandwidth, new FFT window types, filter shape.
This will require existing code to be modified due to change in enumerated control SGRAM Settings.

Modified tkrsa6100 Config ACPR Settings.vi to add video bandwidth and center frequency functions.
This will require existing code to be modified due to change in enumerated control ACPR Settings.

Modified tkrsa6100 Config MCPR Settings.vi to add video bandwidth and center frequency functions.
This will require existing code to be modified due to change in enumerated control MCPR Settings.

Modified tkrsa6100 Status Events.vi to add Phase Noise and Spurious measurements.
This will require existing code to be modified due to change in enumerated control Msmt.

Modified tkrsa6100 Config Digital Modulation Settings.vi to add 32 and 128QAM modulation types.
This will require existing code to be modified due to change in enumerated control Modulation Type.

_______________________Version 4.1______________________________________________________________________________________
Compatible with RSA6106A/RSA6114A firmware version 1.3.1040.

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Changes for Version 4.1

The following commands were added to tkrsa6100ConfigSpectrumDisplay.vi

The following command adds or deletes the trace legend.
:DISPlay:SPECtrum:WINDow:TRACe:LEGend:STATe On | OFF | 1 | 0
:DISPlay:SPECtrum:WINDow:TRACe:LEGend:STATe?

:DISPlay:WINDow:COLor:SCHeme THUNderstorm | BLIZzard | CLASsic
:DISPlay:WINDow:COLor:SCHeme?
Selects the display color scheme.

This command  sets specan to the maximum full span instead of the maximum real-time span.
(correction to the manual)
:SENSe:SPECtrum:MAX:SPAN 

The following commands set the grid scale to log.
:DISPlay:SPECtrum:SCALe:LOG:STATe(?) ON|OFF|0|1

The following command sets the labels for x axis to either start stop
frequencies, or Center frequency and Span
:DISPlay:SPECtrum:X:LABel(?) SSFReq | CFSPan

The following commands were added to tkrsa6100ConfigMarker.vi
:CALCulate:MARKer:DENSity:THReshold
:CALCulate:MARKer:DENSity:EXCursion
:CALCulate:MARKer:DENSity:SMOothing
 
The following commands were added to tkrsa6100ConfigSpuriousDisplay.vi
This command enables or disables display in Log scale.
:DISPlay:SPURious:SCALe:LOG:STATe(?) ON|OFF|0|1

_______________________________________Version 4.2_____________________________________________________________________________________________________
Compatible with RSA6106A/RSA6114A firmware version 1.3.1040.

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Changes for Version 4.2

This VI provides supplementary remote commands for the DPO SVE SignalVu Essentials Software. The SignalVu software enables you to use the DPO7000, DPO70000 and DSA70000 Series Digital Oscilloscopes to analyze RF signal behavior with the same software on the RSA6100A Series Real-Time Spectrum Analyzers. The remote command details are described in the following manuals that can be downloaded from www.tektronix.com/manuals.
RSA6100A Series Real-Time Spectrum Analyzers Programmer Manual
(Tektronix part number 071-1913-xx)
DPO7000, DPO70000 and DSA70000 Series Digital Oscilloscopes
Programmer Manual (Tektronix part number 077-0010-xx)
The SignalVu software supports the use of the RSA6100A Series commands
with some limitations. For example, commands that control output functions
are not supported. The details are given in the following sections, Measurement
Display Support and Remote Command Support. 
Some commands are added for the SignalVu software, which contained in this VI. 

Added commands
Command Description
[SENSe]:SIGNalvu:ACQuisition:CHANnel Selects or queries the oscilloscope data to be used for processing.

[SENSe]:SIGNalvu:ACQuisition:CONTrol:HORizontal Determines whether to enable controlling the oscilloscope horizontal settings.

[SENSe]:SIGNalvu:ACQuisition:CONTrol:SAMPlerate Determines whether to enable controlling the oscilloscope sample rate.

[SENSe]:SIGNalvu:ACQuisition:CONTrol:VERTical Determines whether to enable controlling the oscilloscope vertical settings.

[SENSe]:SIGNalvu:ACQuisition:RESet Resets the oscilloscope.

Tektronix RSA6100A Instrument Driver

_______________________________________Version 4.3____________________________________________________________________________________________________
Compatible with RSA6106A/RSA6114A firmware version 2.0.104.

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Changes for Version 4.3

RSA6K Option 200

 :{FETCh|READ}:EDIagram:{I|Q}?
:DISPlay:DIAGram:X[:SCALe]:*
Demod I&Q vs Time and Frequency Deviation vs Time
[:SENSe]:DDEMod:SYMBol:MAP:
[:SENSe]:DDEMod:SYMBol:MAP[:STATe],
[:SENSe]:DDEMod:SYMBol:MAP:SOURce, CR 275112
:CALibration:CORRection:EXTernal:TYPE
:CALibration:CORRection:EXTernal:EDIT?:NEW
:CALibration:CORRection:EXTernal:EDIT?:INTerpolation
:FETCh|READ:SQUality:RMS|PEAK:EVM:OFFSet
:FETCh|READ:SQUality:RMS|PEAK:EVM:DB:OFFSet
:FETCh|READ:SQUality:PEAK:EVM:LOCation:OFFSet
:DDEMod:{BANDwidth|BWIDth}:TINTerval
:DDEMod:{BANDwidth|BWIDth}:TINTerval:AUTO
:DDEMod:SYMBol:PLOT:POSition
:DDEMod:SYMBol:HSSHift
[:SENSe]:DDEMod:SYMBol:MAP:SOURce
:MMEMory:DDEMod:LOAD:SYMBol:MAP <String>
range of [SENSe]:DDEMod:CARRier:OFFSet
ModType C4FM
add FilterType C4FM_P25, HSINe, SOQPSK_MIL, 
SOQPSK_ARTM, SBPSK_MIL, 
USER1, USER2, USER3, UOTHer
:MMEMory:DDEMod:LOAD:FILTer:MEASurement:USER<x>
:MMEMory:DDEMod:LOAD:FILTer:MEASurement:UOTHer
:MMEMory:DDEMod:LOAD:FILTer:REFerence:USER<x>
renames to [:SENSe]:DDEMod:SYMBol:RATE:SEARch
[:SENSe]:DDEMod:SYMBol:POINts
[:SENSe]:AM|FM|PM:BANDwidth|BWIDth:MEASurement
 removes [:SENSe]:DDEMod:DECode (not supported in SMA4)
[:SENSe]:DDEMod:{BANDwidth|BWIDth}:TINTerval
[:SENSe]:DDEMod:CARRier:OFFSet
[:SENSe]:DDEMod:CARRier:SEARch <boolean> (CR00276060)
CALCulate:CONSte:MARKer<x>:FDEViation? (CR00276067)
CALCulate:DIQVtime:MARKer<x>:TRACe (CR00276068)
CALCulate:EDIagram:MARKer<x>:TRACe (CR00276068)
:{FETCh|READ}:CONSte:FERRor (CR00276139)
:{FETCh|READ}:CONSte:RESults (CR00276139)
:FETC|READ:SQU:PEAK|RMS:EVM:OFFS
:FETC|READ:SQU:PEAK|RMS:EVM:DB:OFFS
:FETC|READ:SQU:PEAK:EVM:LOC:OFFS
DISPlay:WINDow:ACTive:MEASurement (CR00276142)
:FETCh:SQUality:FREQuency:DEViation:TABLe
[:SENSe]:DDEMod:PRESet (CR00276160)
:MMEMory:LOAD:TRACe
:MMEMory:LOAD:TRACe (changes File extension of AM/FM/PM)
:{FETCh|READ}:EDIagram:FDEViation (CR00276173)
:{FETCh|READ}:SQUality:SYMBol:LENGth (CR00276173)
:{FETCh|READ}:CONSte:RESults and :{FETCh|READ}:SQUality:FREQuency:DEViation:TABLe (renames "FSK deviation" to "frequency deviation")
:CALibration:CORRection:EXTernal:TYPE
:CALibration:CORRection:EXTernal:EDIT?:NEW
:CALibration:CORRection:EXTernal:EDIT?:INTerpolation
:INPut:CORRection:EXTernal:TYPE
:INPut:CORRection:EXTernal:EDIT?:NEW
:INPut:CORRection:EXTernal:EDIT?:INTerpolation
:INPut:CORRection:EXTernal:GAIN:STATe
:INPut:CORRection:EXTernal:GAIN:[MAGNitude]
:INPut:CORRection:EXTernal:EDIT?:STATe
:INPut:CORRection:EXTernal:EDIT?:LABel
:MMEMory:LOAD:CORRection:EXTernal:EDIT?
:MMEMory:STORe:CORRection:EXTernal:EDIT?
:MMEMory:DDEMod:LOAD:SYMBol:MAP <file>
[:SENSe]:DDEMod:SYMBol:HSSHift?
[:SENSe]:DDEMod:SYMBol:PLOT:POSition?
[:SENSe]:AM|FM|PM:BANDwidth|BWIDth:MEASurement
:CALCulate:CONSte:MARKer<x>:FDEViation
:CALCulate:DIQVtime:MARKer<x>:TRACe
:CALCulate:EDIagram:MARKer<x>:TRACe
:{FETCh|READ}:CONSte:FERRor
:{FETCh|READ}:CONSte:RESults
:{FETCh|READ}:SQUality:RMS:FERRor
:MMEMory:DDEMod:LOAD:FILTer:MEASurement:USER<x>
:MMEMory:DDEMod:LOAD:FILTer:MEASurement:UOTHer
:MMEMory:DDEMod:LOAD:FILTer:REFerence:USER<x>
:MMEMory:DDEMod:LOAD:FILTer:REFerence:UOTHer
:{FETCh|READ}:SQUality:SYMBol:RATE:ERRor (CR00276237)
 [:SENSe]:DDEMod:CARRier:SEARch to [:SENSe]:DDEMod:CARRier:OFFSet:AUTO (CR00276348)
[:SENSe]:FM|PM:FREQuency:SEARch AUTo|MANual
[:SENSe]:PM:PHASe:SEARch AUTo|MANual
[:SENSe]:FM|PM:FREQuency:SEARch:AUTO <Boolean>
[:SENSe]:PM:PHASe:SEARch:AUTO <Boolean>
[:SENSe]:PM:PHASe:OFFSet <NRf>
[:SENSe]:PM:PHASe:OFFSet?
[:SENSe]:FM|PM:FREQuency:OFFSet:MARKer
[:SENSe]:PM:PHASe:OFFSet:MARKer
:FETCh|READ:AM:RMS
:FETCh|READ:AM:AMINde
:FETCh|READ:AM:MDEPth
:FETCh|READ:FM|PM:FERRor
__________________________________Version 4.5________________________________________________________________________________________________________
Compatible with RSA6106A/RSA6114A/RSA6120A firmware version 2.1.0093.

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Changes for Version 4.5

The following commands were either added or modified.  See the most recent programmer�s manual for details.

SENSe:DDEMod:BANDwidth(BWIDth):AUTO

DISPlay:PULSe:STATistics:PLOT { TRENd | FFT | TTRend }

DISPlay:PULSe:SELect:RESult 

DISPlay:PULSe:RESult:RIPDb

Similar description to DISPlay:PULSe:RESult:RIPPle except the measurement result in dB.

DISPlay:PULSe:RESult:DRODb

Similar description to DISPlay:PULSe:RESult:DROop except the measurement result in dB.

DISPlay:PULSe:RESult:OVERshoot

DISPlay:PULSe:RESult:OVEDb

FETCh:PULSe[:RESult]:DRODb? (Query Only)
READ:PULSe[:RESult]:DRODb? (Query Only)

FETCh:PULSe[:RESult]:RIPDb? (Query Only)
READ:PULSe[:RESult]:RIPDb? (Query Only)

FETCh:PULSe[:RESult]:OVERshoot? (Query Only)
READ:PULSe[:RESult]:OVERshoot? (Query Only)

FETCh:PULSe[:RESult]:OVEDb? (Query Only)
READ:PULSe[:RESult]:OVEDb? (Query Only)

FETCh:PULSe:STATistics:DRODb? (Query Only)
READ:PULSe:STATistics:DRODb? (Query Only)

FETCh:PULSe:STATistics:RIPDb? (Query Only)
READ:PULSe:STATistics: RIPDb? (Query Only)

FETCh:PULSe:STATistics:OVERshoot? (Query Only)
READ:PULSe:STATistics:OVERshoot? (Query Only)

FETCh:PULSe:STATistics:OVEDb? (Query Only)
READ:PULSe:STATistics:OVEDb? (Query Only)

[:SENSe]:MEASurement:FREQuency:CENTer:LOCK (?) ON | OFF  | 0 | 1

:CALCulate:PULSe:STATistics:FFT:CURSor:X(?)
:CALCulate:PULSe:STATistics:FFT:CURSor:Y?		(Query Only)

:DISPlay:PULSe:SELect:RESult(?)

:DISPlay:PULSe:RESult:IRAM(?)
:FETCh:PULSe[:RESult]:IRAM?
:READ:PULSe[:RESult]:IRAM?
:FETCh:PULSe:STATistics:IRAM?
:READ:PULSe:STATistics:IRAM?

DISPlay:PULSe:STATistics:PLOT

DISPlay:PULSe:STATistics:PLOT { TRENd | FFT | TTRend | HISTogram }

FETCh:PULSe:STATistics[:Y]?
READ:PULSe:STATistics[:Y]?

FETCh:PULSe:STATistics:X?
READ:PULSe:STATistics:X?

FETCh:PULSe:STATistics:XY?
READ:PULSe:STATistics:XY?

[SENSe]:PULSe:STATistics:HISTogram:POINts(?)

[SENSe]:PULSe:STATistics:HISTogram:POINts:AUTO(?)

[SENSe]:REANalyze:FIRSt
	
[SENSe]:REANalyze:PREVious

[SENSe]:REANalyze:CURRent

[SENSe]:REANalyze:NEXT

[SENSe]:REANalyze:LAST

[SENSe]:REANalyze:ALL

[SENSe]:REANalyze:PAUSe(?)

[SENSe]:REANalyze:STOP

[SENSe]:REANalyze:SELect:ALL

[SENSe]:REANalyze:SELect:ACQuisition:STARt(?)

[SENSe]:REANalyze:SELect:ACQuisition:STARt:TIMestamp?

[SENSe]:REANalyze:SELect:ACQuisition:STOP(?)

[SENSe]:REANalyze:SELect:ACQuisition:STOP:TIMestamp?

[SENSe]:REANalyze:SELect:ACQuisition:FIRSt?
. 
[SENSe]:REANalyze:SELect:ACQuisition:FIRSt:TIMestamp?

[SENSe]:REANalyze:SELect:ACQuisition:LAST?

[SENSe]:REANalyze:SELect:ACQuisition:LAST:TIMestamp?

[SENSe]:REANalyze:SELect:FRAMe:STARt(?)

[SENSe]:REANalyze:SELect:FRAMe:STARt:TIMestamp?

[SENSe]:REANalyze:SELect:FRAMe:STOP(?)

[SENSe]:REANalyze:SELect:FRAMe:STOP:TIMestamp?

[SENSe]:REANalyze:SELect:FRAMe:FIRSt?

[SENSe]:REANalyze:SELect:FRAMe:FIRSt:TIMestamp?

[SENSe]:REANalyze:SELect:FRAMe:LAST?

[SENSe]:REANalyze:SELect:FRAMe:LAST:TIMestamp?

[SENSe]:REANalyze:ACQuisition:SETTings?

[SENSe]:REANalyze:TIMestamp:DECimal(?)

[SENSe]:REANalyze:DELete:DATA

[SENSe]:REANalyze:SPEed(?)

[SENSE]:REANalyze:CURRent:TIMestamp?

[SENSE]:REANalyze:CURRent:ACQuisition?

[SENSE]:REANalyze:CURRent:FRAMe?

:MMEMory:STORe:IQ:SELEct:LENGth(?)

:MMEMory:STORe:IQ:SELEct:FRAMes(?)

:CALCulate:PULSe:STATistics:FFT:INDicator:X(?)
:CALCulate:PULSe:STATistics:FFT:INDicator:Y? 

DISPlay:PULSe:RESult:IRTime

FETCh:PULSe[:RESult]:IRTime? (Query Only)

READ:PULSe[:RESult]:IRTime? (Query Only)

FETCh:PULSe:STATistics:IRTime? (Query Only)

READ:PULSe:STATistics:IRTime? (Query Only)

CALCulate:PULSe:STATistics:HISTogram:INDicator:X(?)

CALCulate:PULSe:STATistics:HISTogram:INDicator:Y?	(Query Only)

[SENSe]:PULSe:STATistics:HISTogram:ORDinate(?)

[SENSe]:PULSe:FREFerence:CSLope(?)

[SENSe]:PULSe:FREFerence:CSLope:AUTO(?)

[SENSe]:PULSe:ANALyze:IRESponse:CORRection:AMPLitude[:STATe](?)

[SENSe]:PULSe:ANALyze:IRESponse:KOTime(?)

[SENSe]:PULSe:ANALyze:FDOMain:MEASurement:TIME:METHod(?)
[SENSe]:PULSe:ANALyze:IRESponse:MEASurement:TIME:METHod(?)
[SENSe]:PULSe:ANALyze:OVERshoot:MEASurement:TIME:METHod(?)

[SENSe]:PULSe:ANALyze:FDOMain:MEASurement:TIME:RLEVel (?)
[SENSe]:PULSe:ANALyze:IRESponse:MEASurement:TIME:RLEVel (?)
[SENSe]:PULSe:ANALyze:OVERshoot:MEASurement:TIME:RLEVel (?)

[SENSe]:PULSe:ANALyze:FDOMain:MEASurement:TIME:STARt (?)
[SENSe]:PULSe:ANALyze:IRESponse:MEASurement:TIME:STARt (?)
[SENSe]:PULSe:ANALyze:OVERshoot:MEASurement:TIME:STARt (?)

[SENSe]:PULSe:ANALyze:FDOMain:MEASurement:TIME:ALENgth (?)
[SENSe]:PULSe:ANALyze:IRESponse:MEASurement:TIME:ALENgth (?)
[SENSe]:PULSe:ANALyze:OVERshoot:MEASurement:TIME:ALENgth (?)

[SENSe]:PULSe:ANALyze:FDOMain:MEASurement:TIME:RLENgth (?)
[SENSe]:PULSe:ANALyze:IRESponse:MEASurement:TIME:RLENgth (?)
[SENSe]:PULSe:ANALyze:OVERshoot:MEASurement:TIME:RLENgth (?)

_________________________________________________________Version 5.0____________________________________________________________________________________________________________________________________
Compatible with RSA6106A/RSA6114A/RSA6120A firmware version 2.3.171.

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Changes for Version 5.0

:SYSTem:KLOCk ?This enables or disables local lockout mode

DISPlay:{FSETtling | PSETtling}:TIME:DECimal <value>
DISPlay:{FSETtling | PSETtling}:TIME:DECimal?
DISPlay:{FSETtling | PSETtling}:WINDow:TRACe:GRATicule:GRID:STATe(?)
DISPlay:{FSETtling | PSETtling}:MARKer:SHOW:STATe(?)
DISPlay:{ FSETtling | PSETtling }:X[:SCALe] Sets or queries the horizontal scale.
DISPlay:{ FSETtling | PSETtling }:X[:SCALe]:AUTO Sets the horizontal scale automatically.
DISPlay:{ FSETtling | PSETtling }:X[:SCALe]:AUTO:STATe Determines whether to set the horizontal scale automatically or manually.
DISPlay:{ FSETtling | PSETtling }:X[:SCALe]:MAXimum? Queries the upper limit of the horizontal scale setting range.
DISPlay: { FSETtling | PSETtling }:X[:SCALe]:MINimum? Queries the lower limit of the horizontal scale setting range.
DISPlay:{ FSETtling | PSETtling }:X[:SCALe]:OFFSet Sets or queries the minimum horizontal value (left edge).
DISPlay:{ FSETtling | PSETtling }:X[:SCALe]:OFFSet:MAXimum? Queries the upper limit of the horizontal offset setting range.
DISPlay:{ FSETtling | PSETtling }:X[:SCALe]:OFFSet:MINimum? Queries the lower limit of the horizontal offset setting range.
DISPlay:{ FSETtling | PSETtling }:Y[:SCALe] Sets or queries the vertical scale.
DISPlay:{ FSETtling | PSETtling }:Y[:SCALe]:AUTO Sets the vertical scale automatically.
DISPlay:{ FSETtling | PSETtling }:Y[:SCALe]:OFFSet Sets or queries the vertical offset.
DISPlay:{FSETtling | PSETtling}:Y[:SCALe]:PDIVision(?)
DISPlay:SGRam:TIME:SCALe:PER:DIVision(?)
DISPlay:SGRam:TIME:OVERlap:PERCent(?)
DISPlay:SGRam:TIME:SPECtrums:PERLine?
DISPlay:SGRam:TIME:OFFSet:DIVisions(?)
DISPlay:SGRAM:MARKer:SHOW:STATe(?)
DISPlay:SGRAM:SELected:TIMestamp(?)
DISPlay:DPSA:Y[:SCALe]:OFFSet(?)

:FETCh:{FSETtling | PSETtling}:TRACe<x>[:Y]? (Query Only)
:FETCh:{FSETtling | PSETtling}:TRACe<x>:X? (Query Only)
:FETCh:{FSETtling | PSETtling}:TRACe<x>:XY? (Query Only)
:FETCh:{FSETtling | PSETtling}:SETTled[:PASS]? (Query Only)
:FETCh:{FSETtling | PSETtling}:SLMSd[:PASS]? (Query Only)
:FETCh:{FSETtling | PSETtling}:MASK[:PASS]? (Query Only)
:FETCh:{FSETtling | PSETtling}:TIME? (Query Only)
:FETCh:{FSETtling | PSETtling}:FTTime? (Query Only)
:FETCh:{FSETtling | PSETtling}:VALue? (Query Only)
:FETCh:FSETtling:ERRor? (Query Only)
:FETCh:{FSETtling | PSETtling}:SETTled:TIME? (Query Only)
:FETCh:{FSETtling | PSETtling}:SETTled:FREQuency? (Query Only)
:FETCh:{FSETtling | PSETtling}:TRIGger:TIME? (Query Only)
:FETCh:{FSETtling | PSETtling}:STARt:TIME? (Query Only)

[:SENSe]:SGRam:WATerfall:ENABle
[:SENSe]:SGRam:WATerfall:DIRection
[:SENSe]:SGRam:WATerfall:Y[:SCALe]
[:SENSe]:SGRam:WATerfall:Y:OFFSet
[:SENSe]:SGRam:WATerfall:Y:AUTO
[:SENSe]:SGRam:WATerfall:Y:RESet 
[:SENSe]:{FSETtling | PSETtling}:MAXTracepoints
[:SENSe]:{FSETtling | PSETtling}:{BANDwidth | BWIDth}
[:SENSe]:{FSETtling | PSETtling}:{BANDwidth | BWIDth}:ACTual
[:SENSe]:{FSETtling | PSETtling}:FREQuency:CENTer
[:SENSe]:{FSETtling | PSETtling}:FREQuency:OFFSet <NRf>
[:SENSe]:{FSETtling | PSETtling}:TARGet:REFerence { AUTO | MFReq }
[:SENSe]: {FSETtling | PSETtling}:TOLerance <NRf>
[:SENSe]:{FSETtling | PSETtling}:LENGth <NRf>
[:SENSe]:{FSETtling | PSETtling}:LENGth:ACTual? (Query Only)
[:SENSe]:{FSETtling | PSETtling}:SDURation:MINimum
{:SENSe]:FSETtling:SDURation:MINimum).
[:SENSe]:{FSETtling | PSETtling}:MASK:STATe { ON | OFF | 1 | 0 }
[:SENSe]:{FSETtling | PSETtling}:MASK:TIME:REFerence <value>
[:SENSe]:{FSETtling | PSETtling}:MASK:TIME:STARt<x> <value>
[:SENSe]:{FSETtling | PSETtling}:MASK:TIME:STOP <value>
[:SENSe]:{FSETtling | PSETtling}:MASK:LIMit<x> <value>
[:SENSe]:ACQuisition:FSAVe:ENABle(?)
[:SENSe]:ACQuisition:FSAVe:FORMat(?)
[:SENSe]:ACQuisition:FSAVe:NAME:BASE(?)
[:SENSe]:ACQuisition:FSAVe:LOCation(?)
[:SENSe]:ACQuisition:FSAVe:FILEs:MAXimum(?)
[:SENSe]:ACQuisition:OPTimization(?) <param>
[:SENSe]:SPECtrum:BANDwidth:OPTimization(?)
[:SENSe]:SPECtrum:BWIDth:OPTimization(?)
[:SENSe]:SGRam:BANDwidth:OPTimization(?)
[:SENSe]:SGRam:BWIDth:OPTimization(?)
[:SENSe]:DPSA:BANDwidth:OPTimization(?)
[:SENSe]:DPSA:BWIDth:OPTimization(?)
[:SENSe]:ACPower:OPTimize:SPAN(?)
[:SENSe]:MCPower:OPTimize:SPAN(?)
[:SENSe]:SGRam:TIME[:SCALe]:PER:DIVision(?)	
[:SENSe]:SGRam:TIME[:SCALe]:OVERlap:PERCent(?)
[:SENSe]:SGRam:TIME[:SCALe]:PER:UPDate:MINutes(?)
[:SENSe]:SGRam:TIME[:SCALe]:PER:UPDate:SEConds(?)
[:SENSe]:SGRam:TIME[:SCALe]:MODe(?)
[:SENSe]:SGRam:TIME[:SCALe]:SPECtrums:PERLine?
[:SENSe]:SGRam:TIME[:SCALe]:STARt:DIVisions(?)
[:SENSe]:REANalyze:ALL:LOOP
[:SENSe]:SPECtrum:STARt:AUTO(?)
	
:TRACe:{FSETtling | PSETtling}:SMOothing:COUNt
:TRACe:{FSETtling | PSETtling}:SMOothing:ENABle
:TRACe:{FSETtling | PSETtling}:AVERage:COUNt
:TRACe:{FSETtling | PSETtling}:AVERage:ENABle { ON | OFF | 1 | 0 }
:TRACe:{FSETtling | PSETtling}:RESet (Command only)
:TRACe<x>:{FSETtling | PSETtling}:SELect
:TRACe<x>:{FSETtling | PSETtling}:SHOW
:TRACe<x>:{FSETtling | PSETtling}:FREeze

MMEMory:{ FSETtling | PSETtling }:LOAD:TRACe<x> Loads trace data from the specified file.
MMEMory:{ FSETtling | PSETtling }:SHOW:TRACe<x> Enables display of a recalled trace file.
MMEMory:{ FSETtling | PSETtling }:STORe:TRACe<x> Stores trace data in the specified file.

:STATus:{FSETtling | PSETtling}:EVENts? (Query Only)

:CALCulate:MARKer:DRAG:SEARch[:STATe](?)
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:DELTa:X[:TIME]? Returns the delta marker time for the selected marker.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:DELTa:Y? Returns the delta marker for the selected marker.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:MAXimum Moves the marker to the highest peak on the trace.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:PEAK:HIGHer Moves the marker to the next peak higher in amplitude.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:PEAK:LEFT Moves the marker to the next peak to the left on the trace.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:PEAK:LOWer Moves the marker to the next peak lower in amplitude.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:PEAK:RIGHt Moves the marker to the next peak to the right on the trace.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:X[:TIME] Sets or queries the horizontal position (time) of the marker.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:Y? Queries the marker amplitude of the selected marker.
CALCulate:{ FSETtling | PSETtling }:MARKer<x>:TRACe  { TRACE1 | TRACE2 }

______________________________________________________________Version 5.1____________________________________________________________________________________________________________________________

Compatible with RSA5103A/RSA5106A

The files extracted from tkrsa6100.zip should be copied to directory "tkrsa6100" within the Labview instr.lib directory.

Added tkrsa6100 Config OFDM Msmts.vi

Added tkrsa6100 Config OFDM Settings.vi

Added tkrsa6100 Config OFDM Settings 2.vi

Added tkrsa6100 Config OFDM Trace.vi

Added tkrsa6100 Config OFDM Display.vi

Added tkrsa6100 OFDM Constellation Marker Control.vi

Added tkrsa6100 OFDM Channel Response Marker Control.vi

Added tkrsa6100 OFDM Symbol Table Marker Control.vi

Added tkrsa6100 OFDM Msmt Results.vi

Added tkrsa6100 Config SEM Settings.vi

Added tkrsa6100 Config SEM Settings 2.vi

Added tkrsa6100 Config SEM Settings 3.vi

Added tkrsa6100 Config SEM Trace.vi

Added tkrsa6100 Config SEM Display.vi

Added tkrsa6100 SEM Marker Control.vi

Added tkrsa6100 SEM Msmt Results.vi

Added tkrsa6100 DPX Marker Control.vi

Added tkrsa6100 Config RF Input Trigger 4.vi

Added tkrsa6100 Config Signal Priority.vi

Added tkrsa6100 Config Marker 2.vi

Updated VIs List:

tkrsa6100 Config RF In Trigger.vi

tkrsa6100 Config Spectrum Settings 2.vi

tkrsa6100 Config Sepctrum Trace.vi

tkrsa6100 Config Spectrogram Trace.vi

tkrsa6100 Config Spurious Trace.vi

tkrsa6100 Config Spurious Settings.vi

tkrsa6100 Config Spurious Settings 2.vi

tkrsa6100 Config Analysis.vi

tkrsa6100 Config DPSA Settings 2.vi

tkrsa6100 Config RF Msmts.vi


______________________________________________________________Version 5.2____________________________________________________________________________________________________________________________

Compatible with RSA5115/RSA5126

This driver has not been tested on the RSA5115 or RSA5126.

Modified VIs:
Initialize.vi
Revision Query.vi


